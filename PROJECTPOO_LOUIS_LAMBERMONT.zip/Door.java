public class Door {
    private String key;

    public Door( String key){
        this.key = key;
    }

   public String getKey(){ 
        return this.key;
   }

}


